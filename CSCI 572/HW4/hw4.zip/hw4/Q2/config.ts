import { Config } from "../../gpt-crawler/src/config";

export const defaultConfig: Config = {
  url: "https://www.reddit.com/r/USC/",
  match: "https://www.reddit.com/r/USC/**",
  maxPagesToCrawl: 50,
  outputFileName: "output.json",
  maxTokens: 2000000,
};
