import re
import json

def open_queries(file):
    with open(file, 'r') as q:
        lines = q.readlines()
        return lines

def read_json():
    with open("data/Google_Result4.json", "r") as g:
        g_res = json.load(g)
    with open("data/hw1.json", "r") as d:
        ddg_res = json.load(d)
    return ddg_res, g_res

def change_url(url):
    url = re.sub(r'^https?://', '', url)
    url = re.sub(r'^www\.', '', url)
    url = url.rstrip('/')
    url = url.lower()
    return url

def find_matches(query, g_res, ddg_res):
    return [(g_index, ddg_index) 
            for ddg_index, ddg_url in enumerate(ddg_res[query])
            for g_index, g_url in enumerate(g_res[query])
            if change_url(ddg_url) == change_url(g_url)]

def calc_p(match):
    length = len(match)
    if length < 2:
        return 0 if length == 0 else 1 if match[0][0] == match[0][1] else 0
    diff = sum((a - b) ** 2 for a, b in match)
    p = 1 - ((6 * diff) / (length * (length ** 2 - 1)))
    return p

def write_csv(stats):
    with open("data/hw1.csv", "w") as f:
        f.write("Queries, Number of Overlapping Results, Percent Overlap, Spearman Coefficient\n")
        for query_no, (query, values) in enumerate(stats.items(), start=1):
            if query_no <= 100:
                f.write("Query {}, {}, {}, {}\n".format(query_no, values["Overlap"], values["Percent"], values["Rho"]))
        f.write("Averages, {}, {}, {}\n".format(stats["Averages"]["Overlap"], stats["Averages"]["Percent"], stats["Averages"]["Rho"]))

if __name__ == '__main__':
    stats = {}
    queries = open_queries("data/100QueriesSet4.txt")

    for _, query in enumerate(queries):
        query = query.strip()
        g_res, ddg_res = read_json()
        match = find_matches(query, g_res, ddg_res)
        
        rho = calc_p(match)
        stats[query] = {"Overlap": len(match), "Percent": len(match) * 10, "Rho": rho}

    overlap = sum(value["Overlap"] / 100 for value in stats.values())
    pct = sum(value["Percent"] / 100 for value in stats.values())
    p = sum(value["Rho"] / 100 for value in stats.values())

    stats["Averages"] = {"Overlap": overlap, "Percent": pct, "Rho": p}

    write_csv(stats)
