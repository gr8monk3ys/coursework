import json
import time
import requests
from random import randint
from bs4 import BeautifulSoup
from html.parser import HTMLParser

USER_AGENT = {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:84.0) Gecko/20100101 Firefox/84.0",
}

def open_queries(file):
    with open(file, 'r') as q:
        lines = q.readlines()
        return lines

class SearchEngine:
    @staticmethod
    def search(query, sleep=True):
        if sleep:
            time.sleep(randint(10, 50))
        temp_url = '+'.join(query.split())
        url = 'https://duckduckgo.com/html/?q=' + temp_url
        print(url)
        soup = BeautifulSoup(requests.get(url, headers=USER_AGENT).text, "html.parser")
        print(soup.prettify())
        new_results = SearchEngine.scrape_search_result(soup)
        return new_results

    @staticmethod
    def scrape_search_result(soup):
        raw_results = soup.find_all("a", attrs={"class" : "result__a"}, href=True)

        results = []
        for result in raw_results:
            link = result.get('href')
            results.append(link)
            if len(results) == 10:
                break
        print(results)
        return results

def create_json(queries):
    data = {}
    for query in queries:
        urls = SearchEngine.search(query)
        data[query] = urls
    return data  

if __name__ == '__main__':
    queries = 'data/100QueriesSet4.txt'

    query_list = open_queries(queries)
    results = create_json(query_list)

    with open('data/hw1.json', 'w') as f:
        json.dump(results, f, indent=4)
