import csv
from collections import defaultdict
from urllib.parse import urlparse

def analyze_fetch_csv(file_path):
    attempts = 0
    success = 0
    failed_or_aborted = 0
    status_codes = defaultdict(int)

    with open(file_path, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            attempts += 1
            status = row['Status']
            if status.startswith('2'):
                success += 1
            else:
                failed_or_aborted += 1
            status_codes[status] += 1

    return attempts, success, failed_or_aborted, status_codes

def analyze_visit_csv(file_path):
    sizes_ranges = {"< 1KB": 0, "1KB ~ <10KB": 0, "10KB ~ <100KB": 0, "100KB ~ <1MB": 0, ">= 1MB": 0}
    content_types = defaultdict(int)
    total_urls = 0

    with open(file_path, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            size = int(row['Size'])
            content_type = row['Content-Type']
            total_urls += 1

            if size < 1024:
                sizes_ranges["< 1KB"] += 1
            elif size < 10240:
                sizes_ranges["1KB ~ <10KB"] += 1
            elif size < 102400:
                sizes_ranges["10KB ~ <100KB"] += 1
            elif size < 1048576:
                sizes_ranges["100KB ~ <1MB"] += 1
            else:
                sizes_ranges[">= 1MB"] += 1

            content_types[content_type] += 1

    return sizes_ranges, content_types, total_urls

def analyze_urls_csv(file_path, root_domain):
    urls_inside = set()
    urls_outside = set()

    with open(file_path, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            url = row['URL']
            if row['In/Out'] == 'OK':
                urls_inside.add(url)
            else:
                urls_outside.add(url)

    total_unique_urls = len(urls_inside) + len(urls_outside)
    return total_unique_urls, len(urls_inside), len(urls_outside)

def write_report(file_path, fetch_results, visit_results, urls_results):
    with open(file_path, mode='w', encoding='utf-8') as file:

        file.write("Name: Lorenzo Scaturchio\n")
        file.write("USC ID: 4935685780\n")
        file.write("News site crawled: usatoday.com\n\n")

        file.write("Fetch Statistics\n")
        file.write("================\n")
        file.write(f"# fetches attempted: {fetch_results[0]}\n")
        file.write(f"# fetches succeeded: {fetch_results[1]}\n")
        file.write(f"# fetches failed or aborted: {fetch_results[2]}\n\n")

        file.write("File Sizes:\n")
        file.write("===========\n")
        for size, count in visit_results[0].items():
            file.write(f"{size}: {count}\n")
        file.write("\n")

        file.write("Content Types:\n")
        file.write("===============\n")
        for content_type, count in visit_results[1].items():
            file.write(f"{content_type}: {count}\n")
        file.write("\n")

        file.write("Status Codes:\n")
        file.write("==============\n")
        for status, count in fetch_results[3].items():
            file.write(f"{status}: {count}\n\n")

        file.write("Outgoing URLs:\n")
        file.write("==============\n")
        file.write(f"Total unique URLs extracted: {urls_results[0]}\n")
        file.write(f"# unique URLs within News Site: {urls_results[1]}\n")
        file.write(f"# unique URLs outside News Site: {urls_results[2]}\n\n")

if __name__ == "__main__":
    fetch_file_path = 'fetch_usatoday.csv'
    visit_file_path = 'visit_usatoday.csv'
    urls_file_path = 'urls_usatoday.csv'
    report_file_path = 'CrawlReport_usatoday.txt'

    root_domain = "usatoday.com"

    fetch_results = analyze_fetch_csv(fetch_file_path)
    visit_results = analyze_visit_csv(visit_file_path)
    urls_results = analyze_urls_csv(urls_file_path, root_domain)
    write_report(report_file_path, fetch_results, visit_results, urls_results)

    print(f"Report generated: {report_file_path}")

