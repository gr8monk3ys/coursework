import requests
from bs4 import BeautifulSoup
import csv
from urllib.parse import urlparse, urljoin
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

base_url = "https://www.usatoday.com"

fetched_urls = set()
visited_urls = set()
external_urls = set()

fetch_rows = []
visit_rows = []
urls_rows = []

traversed_links = 0
max_traversed_links = 10000
# max_traversed_links = 20000

# Delay between requests to respect politeness policies
request_delay = 1

def fetch_url(url, session, timeout=10):
    try:
        time.sleep(request_delay)  # Politeness delay
        response = session.get(url, timeout=timeout)
        return response
    except requests.exceptions.RequestException as e:
        print(f"Timeout when requesting {url}: {e}")
    return None

def crawl(url, session, depth=0, max_depth=3):
    global traversed_links
    if url in fetched_urls or depth > max_depth or traversed_links >= max_traversed_links:
        return set()
    
    response = fetch_url(url, session)
    if response is None:
        return set()

    status_code = response.status_code
    fetch_rows.append({"URL": url, "Status": status_code})
    fetched_urls.add(url)

    internal_links = set()
    if status_code == 200 and 'text/html' in response.headers['Content-Type']:
        visited_urls.add(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        size = len(response.content)
        outlinks = [a.get('href') for a in soup.find_all('a', href=True)]
        visit_rows.append({"URL": url, "Size": size, "Outlinks": len(outlinks), "Content-Type": response.headers['Content-Type']})

        for link in outlinks:
            full_link = urljoin(url, link)
            parsed_link = urlparse(full_link)
            if parsed_link.netloc and parsed_link.scheme in ['http', 'https']:
                if base_url in full_link:
                    internal_links.add(full_link)
                    urls_rows.append({"URL": full_link, "In/Out": "OK"})
                else:
                    external_urls.add(full_link)
                    urls_rows.append({"URL": full_link, "In/Out": "N_OK"})
        traversed_links += 1
        if traversed_links % 100 == 0:
            print(f"Traversed {traversed_links} links.")

    return internal_links if depth < max_depth else set()

def start_crawl(base_url, max_depth=3, max_threads=10):
    session = requests.Session()
    session.headers = {'User-Agent': 'Your Custom User-Agent'}
    with ThreadPoolExecutor(max_workers=max_threads) as executor:
        future_to_url = {executor.submit(crawl, base_url, session, 0, max_depth): (base_url, 0)}
        while future_to_url:
            done, _ = as_completed(future_to_url), set(future_to_url.values())
            for future in done:
                urls, current_depth = future_to_url[future]
                new_depth = current_depth + 1
                for url in future.result() or set():
                    if url not in fetched_urls and len(future_to_url) < max_traversed_links:
                        future_to_url[executor.submit(crawl, url, session, new_depth, max_depth)] = (url, new_depth)
                del future_to_url[future]

def write_csv(file_path, fieldnames, rows):
    with open(file_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)

if __name__ == "__main__":
    start_crawl(base_url, max_depth=4, max_threads=100)
    write_csv('fetch_usatoday.csv', ['URL', 'Status'], fetch_rows)
    write_csv('visit_usatoday.csv', ['URL', 'Size', 'Outlinks', 'Content-Type'], visit_rows)
    write_csv('urls_usatoday.csv', ['URL', 'In/Out'], urls_rows)
    print("Crawling completed.")
