#include "myLib.h"

int add (int x, int y){
	return x + y;
}

int times (int x, int y){
	return x * y;
}
